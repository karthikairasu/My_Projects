{
    var firstName = 'Chris';
    {
        var firstName_1 = 'Tudor';
        console.log('Name 1: ' + firstName_1);
    }
    console.log('Name 2: ' + firstName);
}

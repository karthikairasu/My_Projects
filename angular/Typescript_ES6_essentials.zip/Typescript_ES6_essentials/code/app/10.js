// //tuple type. 
// let poem: [number,boolean,string];   
// // // OK
// poem = [1, true, 'love']; 
// // poem = [2, false, 'somestring']; 
// // // Error: 'string' is not assignable to 'number'
// poem = [100,'my', true];  

var resultArray=[];
for(var i=0;i < 3;i++){
    resultArray.push(i)
}

console.log(resultArray);


function A(){

}function B(){

}function AA(){

}function AB(){

}function C(){

}
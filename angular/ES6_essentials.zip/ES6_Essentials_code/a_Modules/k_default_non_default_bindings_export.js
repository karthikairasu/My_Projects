export let color = "red";

export default function (num1, num2) { // exporting anonmously 
  return num1 + num2;
}





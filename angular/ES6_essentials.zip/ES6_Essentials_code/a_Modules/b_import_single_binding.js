// import just one

import { sum } from "./a_exportingModules";  

console.log(sum(1, 2)); // 3  

// sum = 1; // throws an error
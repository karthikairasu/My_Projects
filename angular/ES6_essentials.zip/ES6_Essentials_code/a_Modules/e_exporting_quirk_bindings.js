export var name = "Nicholas";

export function setName(newName) { // privileged method 
  name = newName;
}






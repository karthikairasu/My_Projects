// export data
export var color = "red";

export const magicNumber = 7;
